const { input, password, select, confirm } = require('@inquirer/prompts');
const mysql = require('mysql2/promise');
const DttManager = require('./service/DttManager.service');



class Manager
{
    constructor()
    {
        this.connection = null;
        this.hostname = null;
        this.db_user = null;
        this.db_pass = null;
        this.db_name = null;
    }

    async AskDbHostname()
    {
        return await input({
            message: "Database Host name: ",
            default: "localhost"
        });
    }

    async AskDbUsername()
    {
        return await input({
            message: "Database Username: ",
            default: "root"
        });
    }

    async AskDbPassword()
    {
        return await password({
            message: "Database Password: ",
            mask: true
        });
    }

    async AskDbname()
    {
        return await input({
            message: "Database name: ",
        });
    }

    async SimpleAskDatabaseConnection()
    {
        this.hostname = await this.AskDbHostname();
        this.db_user = await this.AskDbUsername();
        this.db_pass = await this.AskDbPassword();
        this.db_name = await this.AskDbname();
    }

    async TestDatabaseConnection()
    {
        try
        {
            const connection = await mysql.createConnection({
                ...this.GetSimpleConnectionConfig()
            });


            await connection.end();
            return true;
        }
        catch (err)
        {
            console.error(`Error connection to MYSQL database: ${err}`);

            return false;
        }
    }

    // test database connection
    async TdbcManager()
    {
        await this.SimpleAskDatabaseConnection();


        console.clear();
        this.SimpleConfirmConfigureDatabaseConnection().then(async (value) => {
            if (value)
            {
                const response = await this.TestDatabaseConnection();
        
                console.log(
                    response ? "Connection Database successfully!" : "Database Connection Failed!"
                );
            }
            else
            {
                console.clear();
                return this.TdbcManager();
            }
        });
    }

    // delete topic test
    async DttManager()
    {
        await this.SimpleAskDatabaseConnection();

        
        console.clear();
        this.SimpleConfirmConfigureDatabaseConnection().then(async (value) => {
            if (value)
            {
                if ((await this.ConnectionDatabase()))
                {
                    return new DttManager(this.connection);
                }
            }
            else
            {
                console.clear();
                return this.DttManager();
            }
        });
    }
    
    SimpleConfirmConfigureDatabaseConnection()
    {
        const  { hostname, db_user, db_pass, db_name } = this.GetSimpleDatabaseConnection();

        console.log(`Database Configure Infomation Before Connection?\nhostname: ${hostname}\ndatabase username: ${db_user}\ndatabase password: ${db_pass}\ndatabase name: ${db_name}`);
        return confirm({
            message: "All Fields your configure is correct?"
        });
    }

    GetSimpleConnectionConfig()
    {
        const  { hostname, db_user, db_pass, db_name } = this.GetSimpleDatabaseConnection();

        return {
            host: hostname,
            user: db_user,
            password: db_pass,
            database: db_name
        };
    }

    GetSimpleDatabaseConnection()
    {
        return {
            hostname: this.hostname,
            db_user: this.db_user,
            db_pass: this.db_pass,
            db_name: this.db_name,
        }
    }

    async ConnectionDatabase()
    {
        try
        {
            this.connection = await mysql.createConnection({
                ...this.GetSimpleConnectionConfig()
            });

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }
}    



const main = async () =>
{
    select({
        message: "Select your manage?",
        choices: [
            {
                name: "Delete Topic Test",
                value: "dtt",
                description: "Delete some topic for production not required!"
            },
            {
                name: "Test Connection Database",
                value: "tdbc",
                description: "Test Configure database and connection!"
            },
            {
                name: "Exit",
                value: "exit",
                description: "Close me!"
            }
        ]
    }).then((value) => {
        const manager = new Manager();

        switch (value)
        {
            case "dtt":
                return manager.DttManager();
                break

            case "tdbc":
                return manager.TdbcManager();
                break

            default:
                console.error("Some case not found!");
                break
        }

        return
    });
    // input({
    //     message: "Host Database: "
    // }).then((value) => console.log(value));
}



main();
