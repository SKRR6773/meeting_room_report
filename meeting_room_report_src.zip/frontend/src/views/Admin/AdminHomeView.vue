<template>
    <div>
        <RouterView />
    </div>
</template>
<script setup>
    import { RouterView } from 'vue-router';
</script>