<template>
    <nav class="navbar shadow border">
        <div class="container">
            <a href="#" class="navbar-brand" @click="toTopicEmptyPage"><h4 class="text-secondary">{{ get_brand_name }}</h4></a>

            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item me-1">
                        <li class="nav-item me-1">
                            <button type="button" class="btn text-secondary">
                                <label for="page1" class="pt-none">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" fill="currentColor" class="bi bi-translate" viewBox="0 0 16 16">
                                        <path d="M4.545 6.714 4.11 8H3l1.862-5h1.284L8 8H6.833l-.435-1.286zm1.634-.736L5.5 3.956h-.049l-.679 2.022z"/>
                                        <path d="M0 2a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v3h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-3H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zm7.138 9.995q.289.451.63.846c-.748.575-1.673 1.001-2.768 1.292.178.217.451.635.555.867 1.125-.359 2.08-.844 2.886-1.494.777.665 1.739 1.165 2.93 1.472.133-.254.414-.673.629-.89-1.125-.253-2.057-.694-2.82-1.284.681-.747 1.222-1.651 1.621-2.757H14V8h-3v1.047h.765c-.318.844-.74 1.546-1.272 2.13a6 6 0 0 1-.415-.492 2 2 0 0 1-.94.31"/>
                                    </svg>
                                </label>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="btn text-secondary" @click="SwitchTheme">
                                <label for="" class="pt-none">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" fill="currentColor" class="bi bi-moon-stars" viewBox="0 0 16 16">
                                        <path d="M6 .278a.77.77 0 0 1 .08.858 7.2 7.2 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277q.792-.001 1.533-.16a.79.79 0 0 1 .81.316.73.73 0 0 1-.031.893A8.35 8.35 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.75.75 0 0 1 6 .278M4.858 1.311A7.27 7.27 0 0 0 1.025 7.71c0 4.02 3.279 7.276 7.319 7.276a7.32 7.32 0 0 0 5.205-2.162q-.506.063-1.029.063c-4.61 0-8.343-3.714-8.343-8.29 0-1.167.242-2.278.681-3.286"/>
                                        <path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.73 1.73 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.73 1.73 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.73 1.73 0 0 0 1.097-1.097zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.16 1.16 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.16 1.16 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732z"/>
                                    </svg>
                                </label>
                            </button>
                        </li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</template>
<script setup>
    import { computed } from 'vue';
    import { useRouter } from 'vue-router';

    // asssets
    import transImage from '../../assets/translate.png';

    const router = useRouter();

    const get_brand_name = computed(() => import.meta.env.VITE_VUE_BRAND_NAME);


    const SwitchTheme = () => 
    {
        const current_theme = document.querySelector('html').getAttribute('data-bs-theme');

        document.querySelector('html').setAttribute('data-bs-theme', current_theme === 'light' ? 'dark' : 'light');
    }


    const toTopicEmptyPage = () =>
    {
        router.push({
            path: '/topic'
        }).then(() => {
            location.reload();
        });
    }
</script>