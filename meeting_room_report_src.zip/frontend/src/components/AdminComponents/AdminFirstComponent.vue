<template>
    <div>
        admin hello
    </div>
</template>
<script setup>
    
</script>