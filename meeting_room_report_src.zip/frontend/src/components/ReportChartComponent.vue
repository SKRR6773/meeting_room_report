<template>
    <div>
      <section>
        <div :style="{'min-height': props.minHeight.toString() + 'vh'}">
          <Bar :data="data" :options="options" />
        </div>
      </section>
    </div>
  </template>
  
  <script setup>
  import { ref, defineProps, onMounted } from 'vue';
  import { Chart as ChartJS, Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale } from 'chart.js';
  import { Bar } from 'vue-chartjs';
  import { useStore } from 'vuex';
  
  const props = defineProps({
    data: {
      type: Array
    },
    minHeight: {
      type: String,
      default: '60'
    }
  });
  
  const store = useStore();
  
  ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
  
  const questionSimpleData = ref(store.getters.getSimpleQuestionData.map((row) => row.question_text));
  
  const data = ref({
    labels: questionSimpleData.value.map((_, index) => `ข้อที่ ${index + 1}`),
    datasets: [{
      label: 'คะแนนโหวต',
      backgroundColor: '#f87979',
      data: props.data
    }]
  });
  
  const options = ref({
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        max: 5,
      }
    },
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          title: function(tooltipItems) {
            // Customize the title here
            return questionSimpleData.value[tooltipItems[0].dataIndex];
          }
        }
      }
    }
  });
  
  onMounted(() => {
    // Additional logic on mount if needed
  });
  </script>
  