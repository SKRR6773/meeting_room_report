<template>
    <div>
        <div class="loading" v-show="is_loading">
            <LoadingView :is_show.sync="is_loading" />
        </div>
        <Transition name="fade">
            <div class="container-fluid bg-body-tertiary py-0 my-0 pt-2 pb-3" v-show="!is_loading">
                <header>
                    <!-- <RouterLink to="/">Home</RouterLink> -->
                    <Navbar />
                </header>
                <section class="container mt-4">
                    <hr>
                    <router-view v-slot="{ Component }">
                        <Transition name="fade" mode="out-in">
                            <component :is="Component" />
                        </Transition>
                    </router-view>
                </section>
                <footer class="container">
                    <hr>
                    <section class="text-center text-secondary">
                        <h6>@{{ get_footer_name }}</h6>
                    </section>
                </footer>
            </div>
        </Transition>
    </div>
</template>
<script setup>
    import { computed, onMounted } from 'vue';
    import { RouterLink, RouterView } from 'vue-router';
    import { useStore } from 'vuex';
    import '@/socket';


    import Navbar from './components/Navbar/NavbarComponent.vue';
    import LoadingView from './views/Loading/LoadingView.vue';


    const store = useStore();


    const get_footer_name = computed(() => import.meta.env.VITE_VUE_FOOTER_NAME);
    const is_loading = computed(() => store.getters.getLoading);

    onMounted(() => {
        if (!!localStorage.getItem('user_details') && !!localStorage.getItem('user_token'))
        {
            const user_details = localStorage.getItem('user_details');
            const user_token = localStorage.getItem('user_token');


            store.commit('updateUserDetails', user_details);
            store.commit('updateUserToken', user_token);

            store.commit('verifyUserTokenAndUpdateUser');
        }


        // setTimeout(() => store.commit('setLoading', false), 800);
    });
</script>
<style scoped>
    .fade-enter-active,
    .fade-leave-active {
        transition: opacity 0.3s ease;
    }

    .fade-enter-from,
    .fade-leave-to {
        opacity: 0;
    }
</style>
