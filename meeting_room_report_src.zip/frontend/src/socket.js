// import { io } from 'socket.io-client';


// const socket = io(import.meta.env.VITE_VUE_SOCK_URL);


// socket.on('connect', () => {
//     console.log("Connected to server!");
// });


// socket.on('message', (msg) => {
//     // alert(msg);
//     console.log(msg);
// });