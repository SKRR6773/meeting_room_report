const prompt = require('@inquirer/prompts');
const { checkbox } = prompt;


module.exports = class {
    constructor(connection)
    {
        this.conn = connection;
        

        this.Main();
    }
    
    async Main()
    {
        // console.log(this.conn);
    
        // this.conn.end();

        const topics = await this.SelectAllMeetingTopics();
        console.log(topics);

        const topics_id = await checkbox({
            message: "Want to Delete Topics Names?",
            prefix: "Topics name: ",
            choices: topics.map((row) => {
                return {
                   name: row.name,
                   value: row.id
               }
            })
        });


        console.log(topics_id);
        
        const votes_id = (await Promise.all(topics_id.map(async (topic_id) => {
            const response = await this.SelectMeetingVotesWithTopicId(topic_id);

            return response;
        }))).reduce((curr, row) => {
            curr = curr.concat(row.map((subrow) => subrow.id));
            // console.log('Row => ');
            // console.log(row);
            // curr.push(row);
            return curr;
        }, []);
        
        // .reduce((curr, row) => {
        //     curr = row.map((row) => row.map((subrow) => subrow.id));
        //     return curr;
        // }, []);

        /**
         * .reduce((curr, row) => {
            curr = curr.concat(curr.map((row) => row.id));
            return curr;
        }, [])
         */

        console.log(votes_id);

        const vote_id_histories = (await Promise.all(votes_id.map( async (row) => {
            const response = await this.SelectMeetingVoteHistoriesWithVoteId(row);

            return response;
        }))).reduce((curr, row) => {
            curr = curr.concat(row.map((subrow) => subrow.id));
            return curr;
        }, []);

        console.log(vote_id_histories);
        // await this.SelectAllMeetingVoteHistories();

        await Promise.all([
            {
                func: this.DeleteMeetingVoteHistoriesWithVoteHistoryId.bind(this),
                data: vote_id_histories
            },
            {
                func: this.DeleteMeetingVotesWithVoteId.bind(this),
                data: votes_id
            },
            {
                func: this.DeleteMeetingTopicsWithTopicId.bind(this),
                data: topics_id
            },
        ].map( async (row) => {
            return await row.data.map( async (subrow) => {
                return row.func(subrow);
            });
        }));

        // const meeting_topics_data = await this.SelectAllMeetingTopics();
        // const meeting_votes_data = await this.SelectAllMeetingVotes();
        // const meeting_vote_histories = await this.SelectAllMeetingVoteHistories();

        // await this.TruncateMeetingVoteHistories();
        // await this.TruncateMeetingVotes();
        // await this.TruncateMeetingTopics();

        // await Promise.all([
        //     {
        //         func: this.InsertMeetingTopicsWithJson.bind(this),
        //         data: meeting_topics_data
        //     },
        //     {
        //         func: this.InsertMeetingVotesWithJson.bind(this),
        //         data: meeting_votes_data
        //     },
        //     {
        //         func: this.InsertMeetingVoteHistoriesWithJson.bind(this),
        //         data: meeting_vote_histories
        //     }
        // ].map( async (row) => {
        //     return await row.data.map( async (subrow) => {
        //         return row.func(subrow);
        //     });
        // }));

        this.conn.end();
    }

    async DeleteMeetingTopicsWithTopicId(topic_id)
    {
        try
        {
            await this.conn.execute("DELETE FROM meeting_topics WHERE id = ?", [topic_id, ]);

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async DeleteMeetingVotesWithVoteId(vote_id)
    {
        try
        {
            await this.conn.execute("DELETE FROM meeting_votes WHERE id = ?", [vote_id, ]);

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async DeleteMeetingVoteHistoriesWithVoteHistoryId(vote_history_id)
    {
        try
        {
            await this.conn.execute("DELETE FROM meeting_vote_histories WHERE id = ?", [vote_history_id, ]);

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async InsertMeetingTopicsWithJson(json={})
    {
        try
        {
            const fields = ["name", "room_id", "details", "people_count", "status_id", "createdAt", "updatedAt"];

            const data = await this.conn.execute(`INSERT INTO meeting_topics (${fields.join(', ')}) VALUES (${fields.map((row) => '?').join(", ")})`, fields.map((row) => json[row]));

            console.log(data);

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }
    
    async InsertMeetingVotesWithJson(json={})
    {
        try
        {
            const fields = ["topic_id", "createdAt", "updatedAt"];
    
            await this.conn.execute(`INSERT INTO meeting_votes (${fields.join(', ')}) VALUES (${fields.map((row) => '?').join(", ")})`, fields.map((row) => json[row]));
    
            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }
    
    async InsertMeetingVoteHistoriesWithJson(json={})
    {
        try
        {
            const fields = ["score", "question_id", "vote_id", "createdAt", "updatedAt"];
    
            await this.conn.execute(`INSERT INTO meeting_vote_histories (${fields.join(', ')}) VALUES (${fields.map((row) => '?').join(", ")})`, fields.map((row) => json[row]));
    
            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }
    
    async SelectMeetingVoteHistoriesWithVoteId(vote_id)
    {
        try
        {
            const [ data, _ ] = await this.conn.execute("SELECT *FROM meeting_vote_histories WHERE vote_id = ?", [vote_id, ]);

            return data;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async SelectMeetingVotesWithTopicId(topic_id)
    {
        try
        {
            const [data, _] = await this.conn.execute("SELECT *FROM meeting_votes WHERE topic_id = ?", [topic_id, ]);

            return data;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async TruncateMeetingTopics()
    {
        try
        {
            await this.conn.execute("TRUNCATE TABLE meeting_topics");

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async TruncateMeetingVotes()
    {
        try
        {
            await this.conn.execute("TRUNCATE TABLE meeting_votes");

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async TruncateMeetingVoteHistories()
    {
        try
        {
            await this.conn.execute("TRUNCATE TABLE meeting_vote_histories");

            return true;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async SelectAllMeetingTopics()
    {
        try
        {
            const [ data, _ ] = await this.conn.execute("SELECT *FROM meeting_topics");

            // console.log(data);

            return data;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async SelectAllMeetingVotes()
    {
        try
        {
            const [ data, _ ] = await this.conn.execute("SELECT *FROM meeting_votes");

            return data;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }

    async SelectAllMeetingVoteHistories()
    {
        try
        {
            const [data, _] = await this.conn.execute("SELECT *FROM meeting_vote_histories");

            return data;
        }
        catch (err)
        {
            console.error(err);
            return false;
        }
    }
};